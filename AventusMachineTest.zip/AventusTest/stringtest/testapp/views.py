from django.shortcuts import render
from .forms import StringForm
from .models import stringtest
# Create your views here.

def stringfind(request):
    if request.method == 'POST':
        fm=StringForm(request.POST)
        mastersting=request.POST['masterstring']
        str1=request.POST['string1']
        str2=request.POST['string2']
        str3=request.POST['string3']
        str4=request.POST['string4']
        mster=[x for x in mastersting]
        print(mster)

        
        
        l=[str1,str2,str3,str4]
        remove_list=[]
        for i in l:
            list1=[]
            list1[:0]=i
                
            for index,item in enumerate(mster):
                if item in list1:
                    remove_list.append(item)
                    del mster[index]
            print(mster)
            if item in remove_list:
                print("Already used")
            
       

          

        reg=stringtest(masterstring=mastersting,string1=str1,string2=str2,string3=str3,string4=str4)
        reg.save()
    fm=StringForm()
    return render(request,'base.html',{'form':fm})