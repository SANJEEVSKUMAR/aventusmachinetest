from django.db import models

# Create your models here.
class stringtest(models.Model):
    masterstring=models.CharField(max_length=20)
    string1=models.CharField(max_length=10)
    string2=models.CharField(max_length=10)
    string3=models.CharField(max_length=10)
    string4=models.CharField(max_length=10)