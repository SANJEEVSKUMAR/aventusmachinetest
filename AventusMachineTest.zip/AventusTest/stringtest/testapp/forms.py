from django import forms
from .models import stringtest


class StringForm(forms.ModelForm):
    class Meta:
        model=stringtest
        fields=['masterstring','string1','string2','string3','string4']