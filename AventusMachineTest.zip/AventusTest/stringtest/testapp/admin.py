from django.contrib import admin
from .models import stringtest
# Register your models here.

@admin.register(stringtest)
class AdminString(admin.ModelAdmin):
    list_display=('id','masterstring','string1','string2','string3','string4')